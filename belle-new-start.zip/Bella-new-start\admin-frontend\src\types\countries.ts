export interface Country {
  code: string;
  label: string;
  phone: string;
  flag: string;
}
