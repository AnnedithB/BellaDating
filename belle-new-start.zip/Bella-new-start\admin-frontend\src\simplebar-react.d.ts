declare module 'simplebar-react' {
  import SimpleBar from 'simplebar-react/dist/simplebar-react.js';
  export default SimpleBar;
}
