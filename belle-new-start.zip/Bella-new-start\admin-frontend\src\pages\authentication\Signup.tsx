import SignupForm from 'components/sections/authentications/SignupForm';

const Signup = () => {
  return <SignupForm />;
};

export default Signup;
