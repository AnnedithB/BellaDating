declare module 'reactjs-social-login';
