export const mainDrawerWidth = {
  full: 300,
  collapsed: 136,
};
export const documentationPath = '#';
export const storeLink = '#';
export const freeGithubLink = '#';
export const freeThemewagonLink = '#';
